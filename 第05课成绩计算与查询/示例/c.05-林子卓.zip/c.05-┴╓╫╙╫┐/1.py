# 读取ecsel文件并生成对应的文本文件
import openpyxl

class Read_xl(object):
    def __init__(self, xl, wr, txt):
        # 要打开的工作簿名，工作表名和要生成的文本文件名称
        self.xl = xl
        self.wr = wr
        self.txt = txt
        # load_workbook函数不需要关闭文件
        self.wk = openpyxl.load_workbook(xl + ".xlsx")
        self.wc = self.wk[self.wr]
        self.str = ""
        # 最大行数
        self.rows = self.wc.max_row
        # 最大列数
        self.columns = self.wc.max_column
        # 初始化列表ls
        self.write_txt()

    def write_txt(self):
        self.f = open(self.txt + ".txt", "w")
        for i in range(self.rows):
            # 将每行的信息存储到列表中
            for j in range(self.columns):
                cell_value = self.wc.cell(row=i+1, column=j+1).value
                if cell_value is not None:
                    self.f.write(str(cell_value)+" ")
                else:
                    self.f.write(" ")
            self.f.write("\n")
            self.str = ""
        self.f.close()


read = Read_xl("（前3次）2022级导论考试--成绩表", "598854", "598854课程")
read1 = Read_xl("（前3次）2022级导论考试--成绩表", "598856", "598856课程")
read2 = Read_xl("（前3次）2022级导论考试--成绩表", "598858", "598858课程")