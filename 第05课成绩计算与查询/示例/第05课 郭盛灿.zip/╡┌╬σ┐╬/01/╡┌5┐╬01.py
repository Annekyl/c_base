from openpyxl import load_workbook
import openpyxl
workbook1 = load_workbook(filename="（前3次）2022级导论考试--成绩表.xlsx")#文件名
work_book=['598854',"598856","598858"]
for i in range(3):
    s1 = workbook1[work_book[i]]
    name_txt=work_book[i]+"课程.txt"
    f = open(name_txt, 'a')
    A=s1['A']#序号
    B=s1['B']#学号
    C=s1['C']#名字
    D=s1['D']#性别
    F=s1['F']#进制转换
    E=s1['E']#班级
    G=s1['G']#多进制
    H=s1['H']#数据表达
    content=[A,B,C,D,E,F,G,H]
    for i in range(len(A)):

        for n in range(8):
            value = content[n][i].value
            if value is None or value == "":
                value = 0
            if (n==7):
                f.write(str(value) + '\n')
            else:
                f.write(str(value) + ',')

    f.close()
workbook1.close()
