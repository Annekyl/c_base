//将给定文件中的数据读入单链表（动态链表）中，并计算出平均成绩，找出最高成绩和最低成绩的同学
//并显示其信息（学号，姓名，成绩）



#include <stdio.h>
#include <stdlib.h>
#define LEN sizeof(struct Student)//将结构体 struct Student 的大小（字节数）赋值给 LEN

struct Student
{
    int number;               //序号
    int xuehao;               //学号
    char name[10];            //姓名
    int grade;                //成绩
    struct Student *next;     //用于指向链表中的下一个节点。
};

int n;//n用于区分第一位
float average;//平均分
//------------------------------------------------------------------------------------
struct Student *creats(void)
{
    struct Student *head, *s1, *s2, *highest,*lowest;//head是链表的第一个节点，hightest是最高成绩,lowest最低成绩
    FILE *filePointer;

    filePointer = fopen("report card.txt", "r");//打开文件
    //判断文本文档正确打开
    if (filePointer == NULL)
    {
        perror("无法打开文件");
        return NULL;
    }

    char buffer[100];
    head = s1 = s2 = highest = lowest= NULL;
    //去除第一行的“姓名”，“学号”
    if (fgets(buffer, sizeof(buffer), filePointer) != NULL)//检查从文件中读取一行数据是否成功
    {
        n = 0;
        average=0;
    }

    //尾插法构建链表
    while (fgets(buffer, sizeof(buffer), filePointer) != NULL)
    {
        s1 = (struct Student *)malloc(LEN);//分配空间
        //从字符串中按照指定的格式解析数据并将其存储到变量中
        int count0 = sscanf(buffer, "%*s %*s %*s %d", &s1->grade);
        int count1 = sscanf(buffer, "%*s %d %*s %*s", &s1->xuehao);
        int count2 = sscanf(buffer, "%d %*s %*s %*s", &s1->number);
        int count3 = sscanf(buffer, "%*s %*s %s %*s", &s1->name);

        n = n + 1;

        if (n == 1)//第一行
        {
            head = s1;
            highest = s1;
            lowest = s1 ;
        }
        else
        {
            s2->next = s1;
            // 更新最高成绩节点
            if (s1->grade > highest->grade)
            {
                highest = s1;
            }
            //更新最低成绩节点
            if (s1->grade < lowest->grade)
            {
               lowest = s1;
            }
        }

        s2 = s1;
        s1->next = NULL;//该节点是链表的末尾，没有下一个节点
    }

    fclose(filePointer);//关闭文件
    //-------------------------------------输出----------------------------------------------
    printf("平均成绩：\n");
    struct Student *current0 = head;
    while (current0 != NULL)
    {
        average=average+current0->grade;

        //printf("学号：%d, 成绩：%d, 姓名：%s\n", current->xuehao, current->grade,current->name);
        current0 = current0->next;
    }
    printf("%.2f\n",average/162);


    printf("最高分的同学：\n");
    struct Student *current = head;
    while (current != NULL)
    {
        if (current->grade == highest->grade)
        {
            printf("学号：%d, 成绩：%d, 姓名：%s\n", current->xuehao, current->grade,current->name);
        }
        current = current->next;
    }

    printf("最低分的同学：\n");
    struct Student *current2 = head;
    while (current2 != NULL)
    {
        if (current2->grade == lowest->grade)
        {
            printf("学号：%d, 成绩：%d, 姓名：%s\n", current2->xuehao, current2->grade,current2->name);
        }
        current2 = current2->next;
    }

    return head;
}
//----------------------------------------主程序------------------------------------------------
int main()
{
    struct Student *pt;
    pt = creats();
    return 0;
}
