num=int(input("要建立几个带权重的节点？\n请输入个数(当输入的的数大于6时建议全屏)\n"))
print(f"请输入{num}个整数来表示权重(输入的数以逗号分开)")
def find_min(i):
    min1=10000000
    for j in range(i):
        if (node[j][4]==0 and node[j][0]<min1):
            min1=node[j][0]
            dex1=j
    node[dex1][4] = 1
    min1 = 10000000
    for j in range(i):
        if (node[j][4] == 0 and node[j][0] < min1):
            min1 = node[j][0]
            dex2 = j
    node[dex2][4] = 1
    return dex1,dex2
while(1):
    list1= list(map(int, input().split(",")))
    if (len(list1)!=num):
        print("输入有勿！重新输入")
    else:
        break
node=[[0,0,0,0,0,0] for i in range(num*2-1)]# 权重 父节点 左节点 右节点 状态0为没有动
he=sum(list1)
for i in range(num*2-1):

    if (i<num):
        node[i][0]=list1[i]
    else:
        a,b=find_min(i)
        if (a>=num and b>=num):
            node[i][5]=1
        node[a][1]=i
        node[b][1]=i
        node[i][0]= node[a][0]+ node[b][0]
        node[i][2] = a
        node[i][3] = b
node[num*2-2][4]=1

#for i in range(num*2-1):
    #print(f" {i}    权重{node[i][0]}     父节点{node[i][1]}   左节点{node[i][2]}   右节点{node[i][3]}   {node[i][4]}")
import turtle as t
t.pensize(5)
#t.hideturtle()
banjing=50
def drwa(a,b,c): #a为第几个节点   b,c 为要画的坐标
    #print(f"{node[a][0]}   {a}  {b}   {c}")
    global banjing
    if (node[a][4]==0):
        return
    node[a][4] =0
    t.penup()
    t.goto(b,c)
    if (a<num):#原始节点
        t.dot(banjing,"blue")
        #print("1")
        #t.color("while")
    else:
        t.dot(banjing,"red")
        print("2")
    t.dot(banjing-5,"white")
    t.seth(-90)
    t.fd(10)
    #print("3")
    t.write(node[a][0], align="center", font=("宋体", 18, "bold"))
    t.goto(b, c)
    t.pendown()
    if (a!= 2*num-2):#画父节点
        if node[node[a][1]][2]== a : #是左节点
            direction=[60,50,50*(3**0.5)]
        else:#右节点
            direction=[120,-50,50*(3**0.5)]
        t.penup()
        #print("4")
        t.goto(b, c)
        if (node[node[a][1]][0]==he):
            direction[0]=30+(direction[0]/60-1)*120
            direction[1]=(direction[1]/50)*50*(3**0.5)*2
            direction[2]=100
            banjing=150
        if (node[node[a][1]][5]==1 and node[node[a][1]][0]!=he):
            direction[0] = 30 + (direction[0] / 60 - 1) * 120
            direction[1] = (direction[1] / 50) * 50 * (3 ** 0.5)
            direction[2] = 50

        t.seth(direction[0])
        t.fd(25)
        t.pendown()
        t.fd(banjing)
        banjing = 50
        drwa(node[a][1],b+direction[1],c+direction[2])
        banjing=50
    if (a>=num):#画子节点
        for i in range(2):
            #print("5")
            t.penup()
            t.goto(b,c)
            if(node[a][5]==1 and node[a][0] != he):
                t.seth(i * 120 - 150)
                t.fd(25)
                t.pendown()
                t.fd(banjing)
                drwa(node[a][2 + i], b - 50 * (3 ** 0.5) + 100 * (3 ** 0.5) * i, c - 50)



            elif (node[node[a][2+i]][0] == he or node[a][0] == he):
                t.seth(i*120-150)
                t.fd(25)
                t.pendown()
                t.fd(150)
                drwa(node[a][2+i],b-100*(3**0.5)+200*(3**0.5)*i,c-100)

            else:
                t.seth(i*60-120)
                t.fd(banjing/2)
                t.pendown()
                t.fd(banjing)
                drwa(node[a][2+i],b-50+100*i,c-50*(3**0.5))








drwa(0,0,-280)


#print("666")


t.mainloop()
