import turtle
from queue import PriorityQueue


# 定义节点类
class Node:
    def __init__(self, char, weight):
        # 初始化节点
        # 左右子节点初始时为空
        self.char = char
        self.weight = weight
        self.left = None
        self.right = None

    # 为了在优先队列中比较节点，我们需要定义比较方法
    # 定义小于 (<) 的行为。
    def __lt__(self, other):
        return self.weight < other.weight


# 构建哈夫曼树
def build_huffman_tree(nodes):
    pq = PriorityQueue()
    # 将所有节点加入优先队列（基于权重排序）
    for node in nodes:
        pq.put(node)

    # 当队列中有超过一个节点时，循环执行合并操作
    while pq.qsize() > 1:
        # 取出两个频率最小的节点
        left = pq.get()
        right = pq.get()
        # 创建一个新节点，其频率是两个子节点频率之和
        # 新节点成为这两个节点的父节点
        merged = Node(None, left.weight + right.weight)
        merged.left = left
        merged.right = right
        # 将新节点放回优先队列
        pq.put(merged)

    # 返回队列中剩下的唯一节点，即哈夫曼树的根节点
    return pq.get()


# 绘制哈夫曼树
def draw_tree(node, position, angle, distance):
    if node is not None:
        # 移动到当前节点的位置
        turtle.goto(position)
        if node.char is not None:
            # 如果是叶子节点（有字符），则写出字符和权重
            turtle.write(node.char + ',' + str(node.weight), align="center", font=("微软雅黑", 20, "normal"))
        else:
            # 如果是内部节点，则画一个点表示
            turtle.dot()

        # 递归绘制左子树
        if node.left is not None:
            # 计算左子节点的位置
            new_position = (position[0] - distance, position[1] - 50)
            # 移动回当前节点，准备画线
            turtle.goto(position)
            turtle.setheading(angle)
            turtle.down()
            turtle.goto(new_position)
            turtle.up()
            draw_tree(node.left, new_position, angle - 20, distance * 0.5)

        # 递归绘制右子树
        if node.right is not None:
            # 计算右子节点的位置
            new_position = (position[0] + distance, position[1] - 50)
            turtle.goto(position)
            turtle.setheading(-angle)
            turtle.down()
            turtle.goto(new_position)
            turtle.up()
            draw_tree(node.right, new_position, angle - 20, distance * 0.5)


# 初始化数据和turtle设置
# nodes = [Node('A', 3), Node('B', 14), Node('C', 8), Node('D', 7), Node('E', 8)]
nodes = []
i = 0
while 1:
    a = input("请输入字符(结束请输入0)")
    if a == '0':
        break
    b = int(input("请输入权重"))
    nodes.append(Node(a, b))
    i += 1

root = build_huffman_tree(nodes)

turtle.pensize(5)
turtle.color("purple")
turtle.speed(10)  # 设置绘图速度
turtle.up()  # 抬起画笔，移动时不绘制
draw_tree(root, (0, 200), 20, 200)  # 从屏幕顶部中间开始绘制
turtle.hideturtle()  # 隐藏画笔图标
turtle.done()  # 结束绘图
