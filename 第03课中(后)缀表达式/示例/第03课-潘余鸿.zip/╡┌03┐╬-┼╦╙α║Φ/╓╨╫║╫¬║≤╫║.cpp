#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define MAX_SIZE 100

typedef struct {
    char data[MAX_SIZE];
    int top;
} Stack;

void initStack(Stack *s) {
    s->top = -1;
}

int isEmpty(Stack *s) {
    return s->top == -1;
}

int isFull(Stack *s) {
    return s->top == MAX_SIZE - 1;
}

void push(Stack *s, char c) {
    if (isFull(s)) {
        printf("��ջ\n");
        return;
    }
    s->data[++(s->top)] = c;
}

char pop(Stack *s) {
    if (isEmpty(s)) {
        printf("��ջ\n");
        return '\0';
    }
    return s->data[(s->top)--];
}

char peek(Stack *s) {
    if (isEmpty(s)) {
        printf("��ջ\n");
        return '\0';
    }
    return s->data[s->top];
}

int precedence(char op) {
    switch (op) {
        case '+':
        case '-':
            return 1;
        case '*':
        case '/':
            return 2;
        case '^':
            return 3;
    }
    return -1;
}

int isOperand(char c) {
    return (c >= '0' && c <= '9');
}

void infixToPostfix(char *infix, char *postfix) {
    Stack stack;
    initStack(&stack);
    int i, j = 0;
    int len = strlen(infix);

    for (i = 0; i < len; i++) {
        char c = infix[i];
        if (isOperand(c)) {
            while (isOperand(infix[i])) {
                postfix[j++] = infix[i++]; 
            }
            postfix[j++] = '#';
            i--;
        } 
		else {
            if (c == '(') {
                push(&stack, c);
            } 
			else if (c == ')') {
                while (!isEmpty(&stack) && peek(&stack) != '(') {
                    postfix[j++] = pop(&stack);
                }
                if (!isEmpty(&stack) && peek(&stack) != '(') {
                    printf("��Ч����\n");
                    return;
                } else {
                    pop(&stack);
                }
            } 
			else {
                while (!isEmpty(&stack) && precedence(c) <= precedence(peek(&stack))) {
                    postfix[j++] = pop(&stack);
                }
                push(&stack, c);
            }
        }
    }

    while (!isEmpty(&stack)) {
        postfix[j++] = pop(&stack);
    }
    postfix[j] = '\0';
}
                                                                                                                                                                                                                                                                               
int main() {
    char infix[MAX_SIZE];
    char postfix[MAX_SIZE];  

    printf("��׺ ");
    fgets(infix, MAX_SIZE, stdin);
    infix[strlen(infix) - 1] = '\0';
    infixToPostfix(infix, postfix);
    printf("��׺: %s\n", postfix);
    return 0;
}
